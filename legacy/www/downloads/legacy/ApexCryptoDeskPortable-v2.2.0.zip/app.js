/**
 * Apex Crypto Desk — app.js
 * Live market data + interactive chart for the landing page.
 * Data source: CoinGecko public API (no key required, free tier).
 */

(function () {
  'use strict';

  /* ── Config ── */
  const SYMBOLS = ['bitcoin', 'ethereum', 'solana', 'binancecoin', 'ripple', 'cardano'];
  const SYMBOL_MAP = {
    bitcoin: { symbol: 'BTC', name: 'Bitcoin' },
    ethereum: { symbol: 'ETH', name: 'Ethereum' },
    solana: { symbol: 'SOL', name: 'Solana' },
    binancecoin: { symbol: 'BNB', name: 'BNB' },
    ripple: { symbol: 'XRP', name: 'XRP' },
    cardano: { symbol: 'ADA', name: 'Cardano' },
  };
  const CHART_COINS = { BTC: 'bitcoin', ETH: 'ethereum', SOL: 'solana', BNB: 'binancecoin' };
  const REFRESH_MS = 60_000; // 60s to respect CoinGecko free tier

  /* ── State ── */
  let priceCache = {};
  let currentChartSymbol = 'BTC';
  let chartData = {};
  let chartAnimFrame = null;

  /* ── DOM Refs (set on DOMContentLoaded) ── */
  let $marketCards, $tickerInner, $liveStatusBadge, $liveStatusText;
  let $chartCanvas, $chartPrice, $chartChange, $chartLastUpdated, $chartSymbolLabel;

  /* ====================================================
     UTILITIES
     ==================================================== */
  const fmtUSD = (n) => {
    if (n >= 1000) return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (n >= 1) return '$' + n.toFixed(4);
    return '$' + n.toFixed(6);
  };

  const fmtChange = (pct) => {
    const sign = pct >= 0 ? '+' : '';
    return sign + pct.toFixed(2) + '%';
  };

  const fmtTime = (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  const el = (id) => document.getElementById(id);
  const qs = (sel, ctx = document) => ctx.querySelector(sel);

  /* ====================================================
     COINGECKO API
     ==================================================== */
  const COINGECKO_BASE = 'https://api.coingecko.com/api/v3';

  async function fetchPrices() {
    const ids = SYMBOLS.join(',');
    const url = `${COINGECKO_BASE}/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true`;
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  async function fetchChartData(coinId) {
    const url = `${COINGECKO_BASE}/coins/${coinId}/market_chart?vs_currency=usd&days=1&interval=hourly`;
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  /* ====================================================
     MARKET CARDS
     ==================================================== */
  function renderMarketCards(data) {
    if (!$marketCards) return;
    const cards = SYMBOLS.map((id) => {
      const info = SYMBOL_MAP[id];
      const coin = data[id];
      if (!coin) return '';
      const price = coin.usd || 0;
      const change = coin.usd_24h_change || 0;
      const changeClass = change > 0 ? 'change-up' : change < 0 ? 'change-down' : 'change-flat';
      const changeLabel = fmtChange(change);

      return `<div class="market-card" role="group" aria-label="${info.name} price">
        <div class="market-card-symbol">${info.symbol}</div>
        <div class="market-card-name">${info.name}</div>
        <div class="market-card-price">${fmtUSD(price)}</div>
        <div class="market-card-change ${changeClass}">${changeLabel}</div>
      </div>`;
    }).join('');
    $marketCards.innerHTML = cards;
    priceCache = data;
  }

  /* ====================================================
     TICKER STRIP
     ==================================================== */
  function renderTicker(data) {
    if (!$tickerInner) return;

    const items = SYMBOLS.map((id) => {
      const info = SYMBOL_MAP[id];
      const coin = data[id];
      if (!coin) return '';
      const price = coin.usd || 0;
      const change = coin.usd_24h_change || 0;
      const changeClass = change >= 0 ? 'ticker-up' : 'ticker-down';
      const sign = change >= 0 ? '▲' : '▼';
      return `<span class="ticker-item">
        <span class="ticker-symbol">${info.symbol}</span>
        <span class="ticker-price">${fmtUSD(price)}</span>
        <span class="${changeClass}">${sign} ${Math.abs(change).toFixed(2)}%</span>
      </span>`;
    }).join('');

    // Duplicate inside groups for a seamless and mathematically perfect loop
    const group = `<span style="display:inline-flex;gap:2.5rem;padding-right:2.5rem">${items}</span>`;
    $tickerInner.innerHTML = group + group;
  }

  /* ====================================================
     LIVE BADGE
     ==================================================== */
  function setLiveStatus(state, text) {
    if (!$liveStatusBadge || !$liveStatusText) return;
    $liveStatusBadge.className = 'live-badge' + (state === 'error' ? ' error' : '');
    $liveStatusText.textContent = text;
  }

  /* ====================================================
     CANVAS CHART
     ==================================================== */
  function drawChart(canvas, prices, symbol, changeClass) {
    if (!canvas || !canvas.getContext) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const W = rect.width;
    const H = rect.height;

    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.scale(dpr, dpr);

    if (!prices || prices.length < 2) {
      ctx.fillStyle = 'rgba(255,255,255,0.05)';
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = 'rgba(255,255,255,0.25)';
      ctx.font = '13px "Space Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText('Loading chart data…', W / 2, H / 2);
      return;
    }

    const vals = prices.map((p) => p[1]);
    const minVal = Math.min(...vals);
    const maxVal = Math.max(...vals);
    const range = maxVal - minVal || 1;

    const PAD_L = 60;
    const PAD_R = 14;
    const PAD_T = 20;
    const PAD_B = 30;

    const chartW = W - PAD_L - PAD_R;
    const chartH = H - PAD_T - PAD_B;

    const xStep = chartW / (prices.length - 1);
    const toY = (v) => PAD_T + chartH - ((v - minVal) / range) * chartH;
    const toX = (i) => PAD_L + i * xStep;

    // Background
    ctx.fillStyle = 'rgba(0,0,0,0)';
    ctx.clearRect(0, 0, W, H);

    // Grid lines
    const gridLines = 4;
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= gridLines; i++) {
      const y = PAD_T + (chartH / gridLines) * i;
      ctx.beginPath();
      ctx.moveTo(PAD_L, y);
      ctx.lineTo(W - PAD_R, y);
      ctx.stroke();

      // Y-axis labels
      const labelVal = maxVal - (range / gridLines) * i;
      ctx.fillStyle = 'rgba(255,255,255,0.28)';
      ctx.font = `10px "Space Mono", monospace`;
      ctx.textAlign = 'right';
      ctx.fillText(fmtShort(labelVal), PAD_L - 5, y + 3.5);
    }

    // Gradient fill
    const isUp = changeClass === 'up';
    const gradFill = ctx.createLinearGradient(0, PAD_T, 0, PAD_T + chartH);
    if (isUp) {
      gradFill.addColorStop(0, 'rgba(0, 245, 212, 0.25)');
      gradFill.addColorStop(1, 'rgba(0, 245, 212, 0.01)');
    } else {
      gradFill.addColorStop(0, 'rgba(255, 71, 87, 0.25)');
      gradFill.addColorStop(1, 'rgba(255, 71, 87, 0.01)');
    }

    ctx.beginPath();
    ctx.moveTo(toX(0), toY(vals[0]));
    for (let i = 1; i < vals.length; i++) {
      const x0 = toX(i - 1), y0 = toY(vals[i - 1]);
      const x1 = toX(i), y1 = toY(vals[i]);
      const cpx = (x0 + x1) / 2;
      ctx.bezierCurveTo(cpx, y0, cpx, y1, x1, y1);
    }
    ctx.lineTo(toX(vals.length - 1), PAD_T + chartH);
    ctx.lineTo(toX(0), PAD_T + chartH);
    ctx.closePath();
    ctx.fillStyle = gradFill;
    ctx.fill();

    // Line
    const lineColor = isUp ? '#00f5d4' : '#ff4757';
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = 2.5;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(toX(0), toY(vals[0]));
    for (let i = 1; i < vals.length; i++) {
      const x0 = toX(i - 1), y0 = toY(vals[i - 1]);
      const x1 = toX(i), y1 = toY(vals[i]);
      const cpx = (x0 + x1) / 2;
      ctx.bezierCurveTo(cpx, y0, cpx, y1, x1, y1);
    }
    ctx.stroke();

    // Endpoint dot
    const lastX = toX(vals.length - 1);
    const lastY = toY(vals[vals.length - 1]);
    ctx.beginPath();
    ctx.arc(lastX, lastY, 4, 0, Math.PI * 2);
    ctx.fillStyle = lineColor;
    ctx.fill();
    ctx.strokeStyle = '#080d1a';
    ctx.lineWidth = 2;
    ctx.stroke();

    // X-axis time labels — show ~5 evenly spaced
    const labelCount = Math.min(5, prices.length);
    const step = Math.floor((prices.length - 1) / (labelCount - 1));
    ctx.fillStyle = 'rgba(255,255,255,0.28)';
    ctx.font = '10px "Space Mono", monospace';
    ctx.textAlign = 'center';
    for (let i = 0; i < labelCount; i++) {
      const idx = Math.min(i * step, prices.length - 1);
      const ts = prices[idx][0];
      const lbl = new Date(ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
      const x = toX(idx);
      ctx.fillText(lbl, x, PAD_T + chartH + 18);
    }
  }

  function fmtShort(n) {
    if (n >= 1_000_000) return '$' + (n / 1_000_000).toFixed(2) + 'M';
    if (n >= 1_000) return '$' + (n / 1_000).toFixed(1) + 'k';
    if (n >= 1) return '$' + n.toFixed(2);
    return '$' + n.toFixed(5);
  }

  /* ====================================================
     CHART UPDATE
     ==================================================== */
  async function updateChart(symbol) {
    currentChartSymbol = symbol;
    const coinId = CHART_COINS[symbol];
    if (!coinId) return;

    if ($chartSymbolLabel) $chartSymbolLabel.textContent = `${symbol}/USD`;
    if ($chartPrice) $chartPrice.textContent = '…';
    if ($chartChange) {
      $chartChange.textContent = '';
      $chartChange.className = 'chart-change';
    }

    // Use cached prices for header display
    const coinKey = Object.keys(CHART_COINS).find((s) => CHART_COINS[s] === coinId && s === symbol);
    if (coinKey && priceCache[coinId]) {
      const p = priceCache[coinId];
      if ($chartPrice) $chartPrice.textContent = fmtUSD(p.usd);
      const change = p.usd_24h_change || 0;
      const cls = change >= 0 ? 'up' : 'down';
      if ($chartChange) {
        $chartChange.textContent = fmtChange(change);
        $chartChange.className = `chart-change ${cls}`;
      }
    }

    // Load chart data (cache it)
    if (!chartData[symbol]) {
      try {
        const raw = await fetchChartData(coinId);
        chartData[symbol] = raw.prices || [];
      } catch (e) {
        chartData[symbol] = null;
      }
    }

    const prices = chartData[symbol];
    if (prices && prices.length > 0) {
      if (currentChartSymbol !== symbol) return; // Prevent race conditions
      const first = prices[0][1];
      const last = prices[prices.length - 1][1];
      const changeDir = last >= first ? 'up' : 'down';
      if ($chartCanvas) {
        drawChart($chartCanvas, prices, symbol, changeDir);
        if ($chartLastUpdated) {
          $chartLastUpdated.textContent = `Last updated: ${fmtTime(new Date())}`;
        }
      }
    }
  }

  /* ====================================================
     CHART BUTTON HANDLERS
     ==================================================== */
  function setupChartButtons() {
    Object.keys(CHART_COINS).forEach((sym) => {
      const btn = el(`chart-btn-${sym.toLowerCase()}`);
      if (!btn) return;
      btn.addEventListener('click', () => {
        // Update active state
        document.querySelectorAll('.chart-btn').forEach((b) => {
          b.classList.remove('active');
          b.setAttribute('aria-pressed', 'false');
        });
        btn.classList.add('active');
        btn.setAttribute('aria-pressed', 'true');
        updateChart(sym);
      });
    });
  }

  /* ====================================================
     MAIN REFRESH LOOP
     ==================================================== */
  async function refresh() {
    try {
      const data = await fetchPrices();
      renderMarketCards(data);
      renderTicker(data);
      setLiveStatus('live', 'Live');
      // Update chart header price if it's currently displayed
      const coinId = CHART_COINS[currentChartSymbol];
      if (coinId && data[coinId]) {
        const p = data[coinId];
        if ($chartPrice) $chartPrice.textContent = fmtUSD(p.usd);
        const change = p.usd_24h_change || 0;
        const cls = change >= 0 ? 'up' : 'down';
        if ($chartChange) {
          $chartChange.textContent = fmtChange(change);
          $chartChange.className = `chart-change ${cls}`;
        }
      }
    } catch (e) {
      console.warn('[ApexCryptoDesk] Market data fetch failed:', e.message);
      setLiveStatus('error', 'Offline');
      // Show user-friendly error in market cards if still skeletons
      if ($marketCards && $marketCards.querySelector('.skeleton')) {
        $marketCards.innerHTML = `<div class="market-card" style="grid-column:1/-1; text-align:center; opacity:0.5; padding:2rem;">
          <p style="margin:0; font-size:0.9rem;">Unable to load market data. Please check your connection.</p>
        </div>`;
      }
    }
  }

  /* ====================================================
     FOOTER YEAR
     ==================================================== */
  function setFooterYear() {
    const yr = el('footer-year');
    if (yr) yr.textContent = new Date().getFullYear();
  }

  /* ====================================================
     HERO DATE (keep current)
     ==================================================== */
  function setHeroDate() {
    const d = el('hero-updated-date');
    if (d) {
      const today = new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD
      d.textContent = `Updated: ${today}`;
    }
  }

  /* ====================================================
     MOBILE NAV HAMBURGER
     ==================================================== */
  function setupMobileNav() {
    const toggle = el('nav-toggle');
    const navLinks = el('nav-links');
    if (!toggle || !navLinks) return;

    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!expanded));
      navLinks.classList.toggle('open', !expanded);
    });

    // Close on any nav link click (smooth scroll then close)
    navLinks.querySelectorAll('a').forEach((a) => {
      a.addEventListener('click', () => {
        toggle.setAttribute('aria-expanded', 'false');
        navLinks.classList.remove('open');
      });
    });

    // Close on outside click
    document.addEventListener('click', (e) => {
      if (!toggle.contains(e.target) && !navLinks.contains(e.target)) {
        toggle.setAttribute('aria-expanded', 'false');
        navLinks.classList.remove('open');
      }
    });
  }

  /* ====================================================
     INIT
     ==================================================== */
  function init() {
    $marketCards = el('market-cards');
    $tickerInner = el('ticker-inner');
    $liveStatusBadge = el('live-status-badge');
    $liveStatusText = el('live-status-text');
    $chartCanvas = el('priceChart');
    $chartPrice = el('chart-price');
    $chartChange = el('chart-change');
    $chartLastUpdated = el('chart-last-updated');
    $chartSymbolLabel = el('chart-symbol-label');

    setFooterYear();
    setHeroDate();
    setupChartButtons();
    setupMobileNav();

    // Initial data load
    refresh().then(() => {
      updateChart('BTC');
    });

    // Tooltip injection
    let tooltip = el('chart-tooltip');
    if (!tooltip) {
      tooltip = document.createElement('div');
      tooltip.id = 'chart-tooltip';
      tooltip.style.position = 'absolute';
      tooltip.style.display = 'none';
      tooltip.style.pointerEvents = 'none';
      tooltip.style.background = '#0f2235';
      tooltip.style.color = '#fff';
      tooltip.style.padding = '0.5rem 0.8rem';
      tooltip.style.borderRadius = '6px';
      tooltip.style.fontSize = '0.85rem';
      tooltip.style.zIndex = '10';
      tooltip.style.boxShadow = '0 4px 12px rgba(0,0,0,0.2)';
      tooltip.style.fontFamily = '"Space Mono", monospace';
      const wrapper = $chartCanvas.parentElement;
      wrapper.style.position = 'relative';
      wrapper.appendChild(tooltip);
    }

    $chartCanvas.addEventListener('mousemove', (e) => {
      const prices = chartData[currentChartSymbol];
      if (!prices || prices.length < 2) return;
      
      const rect = $chartCanvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const PAD_L = 60;
      const PAD_R = 14;
      const chartW = rect.width - PAD_L - PAD_R;
      
      if (x < PAD_L || x > rect.width - PAD_R) {
        tooltip.style.display = 'none';
        return;
      }
      
      const pct = (x - PAD_L) / chartW;
      let idx = Math.round(pct * (prices.length - 1));
      idx = Math.max(0, Math.min(idx, prices.length - 1));
      
      const p = prices[idx];
      const timeStr = new Date(p[0]).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
      const dateStr = new Date(p[0]).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      const valStr = fmtUSD(p[1]);
      
      tooltip.innerHTML = `<strong style="font-size:1.05rem;color:#7ec8eb">${valStr}</strong><br><span style="opacity:0.7;font-size:0.75rem">${dateStr} ${timeStr}</span>`;
      tooltip.style.display = 'block';
      
      let tX = x + 15;
      if (tX + 130 > rect.width) tX = x - 130;
      tooltip.style.left = tX + 'px';
      
      let tY = e.clientY - rect.top - 30;
      tooltip.style.top = tY + 'px';
    });
    
    $chartCanvas.addEventListener('mouseleave', () => {
      tooltip.style.display = 'none';
    });

    // Periodic refresh
    setInterval(() => {
      refresh();
      // Refresh chart data too
      chartData[currentChartSymbol] = null;
      updateChart(currentChartSymbol);
    }, REFRESH_MS);

    // Redraw chart on resize
    let resizeTimer;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        const prices = chartData[currentChartSymbol];
        if (prices && $chartCanvas) {
          const first = prices[0]?.[1] || 0;
          const last = prices[prices.length - 1]?.[1] || 0;
          drawChart($chartCanvas, prices, currentChartSymbol, last >= first ? 'up' : 'down');
        }
      }, 100);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
