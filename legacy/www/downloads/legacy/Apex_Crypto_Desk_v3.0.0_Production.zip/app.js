/**
 * Apex Crypto Desk — app.js v3.0
 * Premium Market Intelligence Engine
 *
 * Data sources:
 *  - Binance WebSocket  → real-time price streaming (primary)
 *  - CoinGecko REST API → 24h chart historical data + market stats
 *
 * Architecture:
 *  - WebSocket live feed → ticker + price header always fresh
 *  - CoinGecko REST poll (60s) → market cards, volume, 24h change
 *  - Analysis engine     → multi-factor market signal + regime
 *  - NO fake data        → stale state always labeled
 */
(function () {
  'use strict';

  /* ================================================================
     CONFIG
     ================================================================ */
  const COINGECKO_BASE = 'https://api.coingecko.com/api/v3';
  const BINANCE_WS_BASE = 'wss://stream.binance.com:9443/stream?streams=';

  const COINS = [
    { id: 'bitcoin',     symbol: 'BTC', name: 'Bitcoin',     binance: 'btcusdt' },
    { id: 'ethereum',    symbol: 'ETH', name: 'Ethereum',    binance: 'ethusdt' },
    { id: 'solana',      symbol: 'SOL', name: 'Solana',      binance: 'solusdt' },
    { id: 'binancecoin', symbol: 'BNB', name: 'BNB',         binance: 'bnbusdt' },
    { id: 'ripple',      symbol: 'XRP', name: 'XRP',         binance: 'xrpusdt' },
    { id: 'cardano',     symbol: 'ADA', name: 'Cardano',     binance: 'adausdt' },
  ];

  const CHART_COINS = { BTC: 'bitcoin', ETH: 'ethereum', SOL: 'solana', BNB: 'binancecoin' };
  const COINGECKO_REFRESH_MS = 60_000; // 60s for REST polling (rate-limit safe)

  /* ================================================================
     STATE
     ================================================================ */
  let priceCache     = {};    // { coinId: { usd, usd_24h_change, usd_24h_vol } }
  let wsLivePrices   = {};    // { symbol: price } — streaming from Binance WS
  let chartData      = {};    // { symbol: { tf: [[ts, price], ...] } }
  let currentChart   = 'BTC';
  let currentTimeframe = '1D';
  let wsConn         = null;
  let wsReconnects   = 0;
  let wsHeartbeat    = null;
  let lastDataTs     = null;  // last REST data timestamp
  let isOnline       = navigator.onLine;

  /* ================================================================
     DOM REFS
     ================================================================ */
  let $marketCards, $tickerInner, $liveBadge, $liveText;
  let $canvas, $chartPrice, $chartChange, $chartUpdated, $chartLabel;
  let $regimeBadge, $regimeValue, $regimeFreshness;

  /* ================================================================
     FORMATTERS
     ================================================================ */
  const fmt = {
    usd: (n) => {
      if (!isFinite(n)) return '—';
      if (n >= 1000)  return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      if (n >= 1)     return '$' + n.toFixed(4);
      return '$' + n.toFixed(6);
    },
    usdShort: (n) => {
      if (!isFinite(n)) return '—';
      if (n >= 1_000_000) return '$' + (n / 1_000_000).toFixed(2) + 'M';
      if (n >= 1_000)     return '$' + (n / 1_000).toFixed(1) + 'K';
      return '$' + n.toFixed(2);
    },
    pct: (n) => {
      if (!isFinite(n)) return '—';
      const sign = n >= 0 ? '+' : '';
      return sign + n.toFixed(2) + '%';
    },
    vol: (n) => {
      if (!isFinite(n)) return '—';
      if (n >= 1e9) return '$' + (n / 1e9).toFixed(2) + 'B';
      if (n >= 1e6) return '$' + (n / 1e6).toFixed(1) + 'M';
      return '$' + (n / 1e3).toFixed(0) + 'K';
    },
    time: (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }),
    timeShort: (d) => d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
    age: (ms) => {
      if (ms < 60_000) return 'Just now';
      if (ms < 3600_000) return `${Math.round(ms / 60_000)}m ago`;
      return `${Math.round(ms / 3600_000)}h ago`;
    },
  };

  const el  = (id) => document.getElementById(id);
  const qs  = (s, ctx = document) => ctx.querySelector(s);
  const qsa = (s, ctx = document) => ctx.querySelectorAll(s);

  /* ================================================================
     ANALYSIS ENGINE
     Multi-factor signal scoring with strict NO-TRADE conditions
     ================================================================ */
  function analyzeMarket(coinData) {
    const results = {};
    for (const coin of COINS) {
      const d = coinData[coin.id];
      if (!d) { results[coin.id] = null; continue; }

      const change24 = d.usd_24h_change || 0;
      const vol      = d.usd_24h_vol    || 0;
      const price    = d.usd            || 0;

      // Factor 1: Momentum (24h change magnitude + direction)
      let momentumScore = 0;
      if (change24 > 5)       momentumScore = 2;
      else if (change24 > 2)  momentumScore = 1;
      else if (change24 > 0)  momentumScore = 0.5;
      else if (change24 < -5) momentumScore = -2;
      else if (change24 < -2) momentumScore = -1;
      else if (change24 < 0)  momentumScore = -0.5;

      // Factor 2: Volume signal (high vol = conviction)
      let volScore = 0;
      if (vol > 1e9)       volScore = 1;
      else if (vol > 500e6) volScore = 0.5;
      else if (vol < 50e6)  volScore = -0.5; // low volume = unreliable

      // Combined score (-3 to +3)
      const totalScore = momentumScore + volScore;

      // Signal classification
      let signal, signalClass, confidence, riskScore;
      if (Math.abs(totalScore) < 0.5) {
        signal = 'NO TRADE'; signalClass = 'signal-neutral'; confidence = 20; riskScore = 50;
      } else if (totalScore >= 2.5) {
        signal = 'BUY';  signalClass = 'signal-buy'; confidence = 72; riskScore = 35;
      } else if (totalScore >= 1.0) {
        signal = 'WATCH'; signalClass = 'signal-watch'; confidence = 45; riskScore = 55;
      } else if (totalScore <= -2.5) {
        signal = 'SELL';  signalClass = 'signal-sell'; confidence = 68; riskScore = 40;
      } else if (totalScore <= -1.0) {
        signal = 'WATCH'; signalClass = 'signal-watch'; confidence = 40; riskScore = 60;
      } else {
        signal = 'NO TRADE'; signalClass = 'signal-neutral'; confidence = 25; riskScore = 50;
      }

      // Low volume override: downgrade any BUY/SELL to WATCH
      if (vol < 100e6 && (signal === 'BUY' || signal === 'SELL')) {
        signal = 'WATCH'; signalClass = 'signal-watch'; confidence = Math.round(confidence * 0.7);
        riskScore = Math.round(riskScore * 1.2);
      }

      results[coin.id] = {
        signal, signalClass, confidence, riskScore,
        score: totalScore, momentumScore, volScore,
        change24, vol, price,
        factors: {
          momentum: change24 > 0 ? 'Positive 24h drift' : change24 < 0 ? 'Negative 24h drift' : 'Flat',
          volume:   vol > 1e9 ? 'High conviction vol' : vol < 100e6 ? 'Low vol — caution' : 'Moderate vol',
        },
        invalidationNote: change24 > 0
          ? `Signal weakens if price drops below recent lows`
          : `Signal weakens if price breaks above recent highs`,
        disclaimer: 'Not financial advice. Market conditions change rapidly.',
        ts: Date.now(),
      };
    }
    return results;
  }

  function computeMarketRegime(analysis) {
    const signals = Object.values(analysis).filter(Boolean);
    if (!signals.length) return { label: 'Uncertain', cls: 'uncertain', reason: 'No data' };

    const buyCount  = signals.filter(s => s.signal === 'BUY').length;
    const sellCount = signals.filter(s => s.signal === 'SELL').length;
    const avgChange = signals.reduce((a, s) => a + s.change24, 0) / signals.length;

    if (buyCount >= 3 && avgChange > 2)
      return { label: 'Broadly Bullish', cls: 'bullish', reason: `${buyCount}/${signals.length} assets trending up` };
    if (sellCount >= 3 && avgChange < -2)
      return { label: 'Broadly Bearish', cls: 'bearish', reason: `${sellCount}/${signals.length} assets declining` };
    if (Math.abs(avgChange) < 1)
      return { label: 'Sideways / Neutral', cls: 'neutral', reason: 'Mixed signals, low directional pressure' };
    return { label: 'Mixed — Caution', cls: 'uncertain', reason: 'No clear market consensus' };
  }

  /* ================================================================
     LIVE STATUS
     ================================================================ */
  function setLiveStatus(state, text) {
    if (!$liveBadge || !$liveText) return;
    $liveBadge.className = 'live-badge' + (state === 'error' ? ' error' : '');
    $liveText.textContent = text;
    const dot = qs('.live-dot', $liveBadge);
    if (dot) {
      dot.className = 'live-dot';
      if (state === 'error') dot.classList.add('offline');
    }
  }

  /* ================================================================
     MARKET REGIME BANNER
     ================================================================ */
  function updateRegimeBanner(regime) {
    const el_val = el('regime-value');
    const el_reason = el('regime-reason');
    const el_dot = el('freshness-dot');
    const el_age = el('freshness-age');
    if (!el_val) return;
    el_val.textContent = regime.label;
    el_val.className = `regime-value ${regime.cls}`;
    if (el_reason) el_reason.textContent = regime.reason;
    if (el_dot) {
      el_dot.className = `freshness-dot ${lastDataTs ? 'live' : 'stale'}`;
    }
    if (el_age && lastDataTs) {
      el_age.textContent = fmt.age(Date.now() - lastDataTs);
    }
  }

  /* ================================================================
     MARKET CARDS
     ================================================================ */
  function renderMarketCards(coinData, analysis) {
    if (!$marketCards) return;
    const html = COINS.map((coin) => {
      const d = coinData[coin.id];
      const a = analysis[coin.id];
      if (!d) return '';

      const price    = wsLivePrices[coin.symbol] || d.usd || 0;
      const change   = d.usd_24h_change || 0;
      const vol      = d.usd_24h_vol || 0;
      const chgCls   = change > 0 ? 'change-up' : change < 0 ? 'change-down' : 'change-flat';
      const arrow    = change > 0 ? '▲' : change < 0 ? '▼' : '—';
      const sigLabel = a ? a.signal : '—';
      const sigClass = a ? a.signalClass : 'signal-neutral';

      return `<div class="market-card" role="group" aria-label="${coin.name} price and signal" data-coin="${coin.id}">
        <div class="market-card-header">
          <div>
            <div class="market-card-sym">${coin.symbol}</div>
            <div class="market-card-name">${coin.name}</div>
          </div>
          <div class="market-card-signal ${sigClass}">${sigLabel}</div>
        </div>
        <div class="market-card-price" data-live="${coin.symbol}">${fmt.usd(price)}</div>
        <div class="market-card-row">
          <span class="market-card-change ${chgCls}">${arrow} ${Math.abs(change).toFixed(2)}%</span>
          <span class="market-card-vol">${fmt.vol(vol)}</span>
        </div>
      </div>`;
    }).join('');
    $marketCards.innerHTML = html;
  }

  /* ================================================================
     TOP MOVERS SECTION
     ================================================================ */
  function renderTopMovers(coinData) {
    const $wrap = el('top-movers');
    if (!$wrap) return;
    const sorted = COINS
      .map(c => ({ ...c, change: coinData[c.id]?.usd_24h_change || 0 }))
      .sort((a, b) => Math.abs(b.change) - Math.abs(a.change))
      .slice(0, 3);

    $wrap.innerHTML = sorted.map((c, i) => {
      const cls = c.change >= 0 ? 'up' : 'down';
      return `<div class="mover-card">
        <div class="mover-rank">${i + 1}</div>
        <div>
          <div class="mover-sym">${c.symbol}</div>
          <div class="mover-name">${c.name}</div>
        </div>
        <div class="mover-pct ${cls}">${fmt.pct(c.change)}</div>
      </div>`;
    }).join('');
  }

  /* ================================================================
     TICKER STRIP
     ================================================================ */
  function renderTicker(coinData) {
    if (!$tickerInner) return;
    const items = COINS.map((coin) => {
      const d = coinData[coin.id];
      if (!d) return '';
      const price  = wsLivePrices[coin.symbol] || d.usd || 0;
      const change = d.usd_24h_change || 0;
      const cls    = change >= 0 ? 'ticker-up' : 'ticker-down';
      const arrow  = change >= 0 ? '▲' : '▼';
      return `<span class="ticker-item">
        <span class="ticker-symbol">${coin.symbol}</span>
        <span class="ticker-price" data-ticker="${coin.symbol}">${fmt.usd(price)}</span>
        <span class="${cls}">${arrow} ${Math.abs(change).toFixed(2)}%</span>
      </span>`;
    }).join('');
    const group = `<span style="display:inline-flex;gap:0;padding-right:0">${items}</span>`;
    $tickerInner.innerHTML = group + group;
  }

  /* ================================================================
     SIGNAL EXPLANATION CARD
     ================================================================ */
  function renderSignalCard(coinId, analysis) {
    const $card = el('signal-card');
    if (!$card) return;
    const a = analysis[coinId];
    if (!a) { $card.hidden = true; return; }

    $card.hidden = false;
    const confColor = a.confidence >= 65 ? 'var(--emerald)'
      : a.confidence >= 40 ? 'var(--yellow)' : 'var(--red)';

    $card.innerHTML = `
      <div class="signal-card-header">
        <div class="signal-card-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
          </svg>
        </div>
        <div>
          <div class="signal-card-title">Signal Analysis — ${currentChart}/USD</div>
          <div class="signal-card-sub">Updated: ${fmt.time(new Date())}</div>
        </div>
      </div>
      <div class="signal-rows">
        <div class="signal-row">
          <span class="signal-row-label">Signal</span>
          <span class="signal-row-value ${a.signal === 'BUY' ? 'pos' : a.signal === 'SELL' ? 'neg' : 'neu'}">${a.signal}</span>
        </div>
        <div class="signal-row">
          <span class="signal-row-label">Momentum Factor</span>
          <span class="signal-row-value ${a.momentumScore > 0 ? 'pos' : a.momentumScore < 0 ? 'neg' : 'neu'}">${a.factors.momentum}</span>
        </div>
        <div class="signal-row">
          <span class="signal-row-label">Volume Factor</span>
          <span class="signal-row-value ${a.volScore > 0 ? 'pos' : a.volScore < 0 ? 'neg' : 'neu'}">${a.factors.volume}</span>
        </div>
        <div class="signal-row">
          <span class="signal-row-label">Risk Score</span>
          <span class="signal-row-value ${a.riskScore < 45 ? 'pos' : a.riskScore > 60 ? 'neg' : 'neu'}">${a.riskScore}/100</span>
        </div>
        <div class="signal-row">
          <span class="signal-row-label">Invalidation</span>
          <span class="signal-row-value neu" style="font-size:0.7rem;max-width:200px;text-align:right">${a.invalidationNote}</span>
        </div>
      </div>
      <div class="confidence-bar-wrap">
        <div class="confidence-bar-label">
          <span>Confidence</span>
          <span>${a.confidence}%</span>
        </div>
        <div class="confidence-bar">
          <div class="confidence-bar-fill" style="width:${a.confidence}%;background:${confColor}"></div>
        </div>
      </div>
      <p style="font-size:0.7rem;color:var(--text-muted);margin:0.75rem 0 0;line-height:1.5">
        <strong>Disclaimer:</strong> ${a.disclaimer}
        This is market context, not financial advice. Always apply your own risk management.
      </p>`;
  }

  /* ================================================================
     CANVAS CHART — Premium Rendering
     ================================================================ */
  function drawChart(canvas, prices, changeDir) {
    if (!canvas || !canvas.getContext) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const W = rect.width, H = rect.height;

    canvas.width  = W * dpr;
    canvas.height = H * dpr;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, W, H);

    if (!prices || prices.length < 2) {
      ctx.fillStyle = 'rgba(148,163,184,0.2)';
      ctx.font = '12px "Space Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText('Loading chart data…', W / 2, H / 2);
      return;
    }

    const vals   = prices.map(p => p[1]);
    const minVal = Math.min(...vals);
    const maxVal = Math.max(...vals);
    const range  = maxVal - minVal || 1;

    const PAD_L = 64, PAD_R = 16, PAD_T = 18, PAD_B = 28;
    const cW = W - PAD_L - PAD_R;
    const cH = H - PAD_T - PAD_B;

    const toX = (i) => PAD_L + (i / (prices.length - 1)) * cW;
    const toY = (v) => PAD_T + cH - ((v - minVal) / range) * cH;

    // Grid
    const gridCount = 4;
    ctx.strokeStyle = 'rgba(255,255,255,0.05)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= gridCount; i++) {
      const y = PAD_T + (cH / gridCount) * i;
      ctx.beginPath(); ctx.moveTo(PAD_L, y); ctx.lineTo(W - PAD_R, y); ctx.stroke();
      const v = maxVal - (range / gridCount) * i;
      ctx.fillStyle = 'rgba(148,163,184,0.35)';
      ctx.font = '9px "Space Mono", monospace';
      ctx.textAlign = 'right';
      ctx.fillText(fmt.usdShort(v), PAD_L - 6, y + 3.5);
    }

    const isUp    = changeDir === 'up';
    const lineCol = isUp ? '#10b981' : '#ef4444';
    const gradTop = isUp ? 'rgba(16,185,129,0.28)' : 'rgba(239,68,68,0.25)';
    const gradBot = isUp ? 'rgba(16,185,129,0.01)' : 'rgba(239,68,68,0.01)';

    // Area gradient
    const grad = ctx.createLinearGradient(0, PAD_T, 0, PAD_T + cH);
    grad.addColorStop(0, gradTop);
    grad.addColorStop(1, gradBot);

    // Bezier path
    function buildPath() {
      ctx.beginPath();
      ctx.moveTo(toX(0), toY(vals[0]));
      for (let i = 1; i < vals.length; i++) {
        const x0 = toX(i - 1), y0 = toY(vals[i - 1]);
        const x1 = toX(i),     y1 = toY(vals[i]);
        const cpx = (x0 + x1) / 2;
        ctx.bezierCurveTo(cpx, y0, cpx, y1, x1, y1);
      }
    }

    // Fill
    buildPath();
    ctx.lineTo(toX(vals.length - 1), PAD_T + cH);
    ctx.lineTo(PAD_L, PAD_T + cH);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    buildPath();
    ctx.strokeStyle = lineCol;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.stroke();

    // Endpoint pulse dot
    const lx = toX(vals.length - 1);
    const ly = toY(vals[vals.length - 1]);
    ctx.beginPath(); ctx.arc(lx, ly, 3.5, 0, Math.PI * 2);
    ctx.fillStyle = lineCol; ctx.fill();
    ctx.strokeStyle = '#0a0b0f'; ctx.lineWidth = 2.5; ctx.stroke();

    // X labels
    const lblCount = Math.min(5, prices.length);
    const step = Math.floor((prices.length - 1) / (lblCount - 1));
    ctx.fillStyle = 'rgba(148,163,184,0.4)';
    ctx.font = '9px "Space Mono", monospace';
    ctx.textAlign = 'center';
    for (let i = 0; i < lblCount; i++) {
      const idx = Math.min(i * step, prices.length - 1);
      const lbl = fmt.timeShort(new Date(prices[idx][0]));
      ctx.fillText(lbl, toX(idx), PAD_T + cH + 18);
    }

    // Store render meta for crosshair
    canvas._chartMeta = { vals, prices, PAD_L, PAD_R, PAD_T, PAD_B, cW, cH, toX, toY, lineCol };
  }

  function setupChartCrosshair() {
    if (!$canvas) return;
    const wrap = $canvas.parentElement || document.body;

    // Remove old tooltip/crosshair if present
    qsa('.chart-tooltip, .chart-crosshair-v, .chart-crosshair-h', wrap).forEach(e => e.remove());

    const tooltip = document.createElement('div');
    tooltip.className = 'chart-tooltip';
    const cvh = document.createElement('div');
    cvh.className = 'chart-crosshair-v';
    const chh = document.createElement('div');
    chh.className = 'chart-crosshair-h';

    wrap.style.position = 'relative';
    wrap.appendChild(tooltip);
    wrap.appendChild(cvh);
    wrap.appendChild(chh);

    $canvas.addEventListener('mousemove', (e) => {
      const meta = $canvas._chartMeta;
      if (!meta) return;
      const { prices, PAD_L, PAD_R, cW, toX, toY, vals, lineCol } = meta;

      const rect = $canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;

      if (mx < PAD_L || mx > rect.width - PAD_R) {
        tooltip.style.display = 'none';
        cvh.style.display = 'none'; chh.style.display = 'none';
        return;
      }

      const frac = (mx - PAD_L) / cW;
      let idx = Math.round(frac * (prices.length - 1));
      idx = Math.max(0, Math.min(idx, prices.length - 1));

      const [ts, price] = prices[idx];
      const py = toY(price);

      tooltip.innerHTML = `<div class="chart-tooltip-price">${fmt.usd(price)}</div>
        <div class="chart-tooltip-time">${new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} ${fmt.timeShort(new Date(ts))}</div>`;
      tooltip.style.display = 'block';

      // Position tooltip
      let tx = mx + 14;
      if (tx + 130 > rect.width) tx = mx - 140;
      tooltip.style.left  = tx + 'px';
      tooltip.style.top   = Math.max(10, py - 30) + 'px';

      // Crosshair
      cvh.style.display = 'block';
      cvh.style.left   = mx + 'px';
      cvh.style.top    = meta.PAD_T + 'px';
      cvh.style.height = meta.cH + 'px';

      chh.style.display = 'block';
      chh.style.top  = py + 'px';
      chh.style.left = meta.PAD_L + 'px';
      const cRight = rect.width - meta.PAD_R;
      chh.style.width = (cRight - meta.PAD_L) + 'px';
    });

    $canvas.addEventListener('mouseleave', () => {
      tooltip.style.display = 'none';
      cvh.style.display = 'none';
      chh.style.display = 'none';
    });
  }

  /* ================================================================
     CHART DATA + UPDATE
     ================================================================ */
  async function fetchChartData(coinId, tf) {
    let days = '1', interval = '';
    if (tf === '1W')  { days = '7'; interval = '&interval=hourly'; }
    if (tf === '1M')  { days = '30'; interval = '&interval=daily'; }
    if (tf === '1Y')  { days = '365'; interval = '&interval=daily'; }
    // 1D and LIVE -> days=1 (5-minute interval automatically)

    const url = `${COINGECKO_BASE}/coins/${coinId}/market_chart?vs_currency=usd&days=${days}${interval}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!res.ok) throw new Error(`CoinGecko chart: HTTP ${res.status}`);
    return res.json();
  }

  async function updateChart(symbol, tf) {
    if (!symbol) symbol = currentChart;
    if (!tf) tf = currentTimeframe;

    currentChart = symbol;
    currentTimeframe = tf;

    const coinId = CHART_COINS[symbol];
    if (!coinId) return;

    // Update UI controls
    qsa('.asset-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.symbol === symbol);
      b.setAttribute('aria-pressed', b.dataset.symbol === symbol ? 'true' : 'false');
    });
    qsa('.tf-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.tf === tf);
      b.setAttribute('aria-pressed', b.dataset.tf === tf ? 'true' : 'false');
    });

    if ($chartLabel) $chartLabel.textContent = `${symbol}/USD`;

    const tfLabels = { 'LIVE':'Live Session', '1D':'24h', '1W':'7 Days', '1M':'30 Days', '1Y':'1 Year' };
    const badgeEl = el('chart-timeframe-label');
    if (badgeEl) badgeEl.textContent = tfLabels[tf] || tf;

    // Show current WS or cached price
    const livePrice = wsLivePrices[symbol];
    const cachedCoin = priceCache[coinId];
    const displayPrice = livePrice || cachedCoin?.usd || 0;
    if ($chartPrice && displayPrice) $chartPrice.textContent = fmt.usd(displayPrice);

    if (cachedCoin) {
      const chg = cachedCoin.usd_24h_change || 0;
      const cls = chg >= 0 ? 'up' : 'down';
      if ($chartChange) {
        $chartChange.textContent = fmt.pct(chg);
        $chartChange.className = `chart-change ${cls}`;
      }
    }

    if (!chartData[symbol]) chartData[symbol] = {};

    // Load or use cached chart data
    if (!chartData[symbol][tf]) {
      try {
        const raw = await fetchChartData(coinId, tf);
        let prices = raw.prices || [];
        if (tf === 'LIVE') prices = prices.slice(-72); // Last 6 hours approx zoom
        chartData[symbol][tf] = prices;
      } catch {
        chartData[symbol][tf] = null;
      }
    }

    const prices = chartData[symbol][tf];
    if (prices && prices.length > 0 && currentChart === symbol && currentTimeframe === tf) {
      const first = prices[0][1], last = prices[prices.length - 1][1];
      drawChart($canvas, prices, last >= first ? 'up' : 'down');
      if ($chartUpdated) $chartUpdated.textContent = `Updated: ${fmt.time(new Date())}`;

      // Render signal card for this coin
      const analysis = analyzeMarket(priceCache);
      renderSignalCard(coinId, analysis);
    }
  }

  /* ================================================================
     BINANCE WEBSOCKET (real-time price streaming)
     ================================================================ */
  function connectWebSocket() {
    if (wsConn) {
      try { wsConn.close(); } catch {}
    }

    const streams = COINS.filter(c => c.binance)
      .map(c => `${c.binance}@miniTicker`)
      .join('/');
    const url = `${BINANCE_WS_BASE}${streams}`;

    try {
      wsConn = new WebSocket(url);
    } catch {
      scheduleWsReconnect();
      return;
    }

    wsConn.onopen = () => {
      wsReconnects = 0;
      setLiveStatus('live', 'Live — WebSocket');
      startWsHeartbeat();
    };

    wsConn.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        const data = msg.data || msg;
        if (!data || !data.s) return;

        const symbol = data.s.replace('USDT', '');
        const price  = parseFloat(data.c); // close price
        if (!isFinite(price)) return;

        wsLivePrices[symbol] = price;

        // Update live DOM elements
        const $liveEl = qs(`[data-live="${symbol}"]`);
        if ($liveEl) $liveEl.textContent = fmt.usd(price);

        const $tickerEl = qs(`[data-ticker="${symbol}"]`);
        if ($tickerEl) $tickerEl.textContent = fmt.usd(price);

        // Update chart price header if this is current chart
        if (symbol === currentChart) {
          if ($chartPrice) $chartPrice.textContent = fmt.usd(price);
          
          // Append to live chart seamlessly if in LIVE mode
          if (currentTimeframe === 'LIVE' && chartData[symbol] && chartData[symbol]['LIVE']) {
             const arr = chartData[symbol]['LIVE'];
             if (arr.length > 0) {
                const lastTs = arr[arr.length - 1][0];
                const now = Date.now();
                if (now - lastTs > 15000) { // push new node every 15s
                   arr.push([now, price]);
                   if (arr.length > 100) arr.shift();
                } else {
                   arr[arr.length - 1][1] = price; // overwrite last node live
                }
                // Schedule render
                requestAnimationFrame(() => {
                  if (currentChart === symbol && currentTimeframe === 'LIVE') {
                    const first = arr[0][1], last = arr[arr.length-1][1];
                    drawChart($canvas, arr, last >= first ? 'up' : 'down');
                  }
                });
             }
          }
        }
      } catch {}
    };

    wsConn.onerror = () => {
      setLiveStatus('error', 'Stream error');
    };

    wsConn.onclose = () => {
      stopWsHeartbeat();
      setLiveStatus('error', 'Reconnecting…');
      scheduleWsReconnect();
    };
  }

  function scheduleWsReconnect() {
    const delay = Math.min(2000 * Math.pow(2, wsReconnects), 30000);
    wsReconnects++;
    setTimeout(connectWebSocket, delay);
  }

  function startWsHeartbeat() {
    stopWsHeartbeat();
    wsHeartbeat = setInterval(() => {
      if (wsConn && wsConn.readyState === WebSocket.OPEN) {
        wsConn.send(JSON.stringify({ method: 'ping' }));
      }
    }, 20000);
  }

  function stopWsHeartbeat() {
    if (wsHeartbeat) { clearInterval(wsHeartbeat); wsHeartbeat = null; }
  }

  /* ================================================================
     COINGECKO REST POLL (60s)
     Fills in 24h change, volume, and historical chart data
     ================================================================ */
  async function fetchMarketData() {
    const ids = COINS.map(c => c.id).join(',');
    const url = `${COINGECKO_BASE}/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true`;
    const res = await fetch(url, { cache: 'no-store', signal: AbortSignal.timeout(10000) });
    if (!res.ok) throw new Error(`CoinGecko: HTTP ${res.status}`);
    return res.json();
  }

  async function refreshMarketData() {
    try {
      const data = await fetchMarketData();
      priceCache  = data;
      lastDataTs  = Date.now();

      const analysis = analyzeMarket(data);
      const regime   = computeMarketRegime(analysis);

      renderMarketCards(data, analysis);
      renderTicker(data);
      renderTopMovers(data);
      updateRegimeBanner(regime);

      // Update chart price from WS or REST
      const coinId = CHART_COINS[currentChart];
      if (coinId && data[coinId]) {
        const p   = data[coinId];
        const lp  = wsLivePrices[currentChart] || p.usd;
        if ($chartPrice) $chartPrice.textContent = fmt.usd(lp);
        const chg = p.usd_24h_change || 0;
        if ($chartChange) {
          $chartChange.textContent = fmt.pct(chg);
          $chartChange.className  = `chart-change ${chg >= 0 ? 'up' : 'down'}`;
        }
        renderSignalCard(coinId, analysis);
      }

      // If WS not connected, use REST as live status source
      if (!wsConn || wsConn.readyState !== WebSocket.OPEN) {
        setLiveStatus('live', 'Live — 60s refresh');
      }
    } catch (err) {
      console.warn('[ApexCryptoDesk] Market data fetch failed:', err.message);
      setLiveStatus('error', 'Data Unavailable');
      if ($marketCards && $marketCards.querySelector('.skeleton')) {
        $marketCards.innerHTML = `<div class="market-card" style="grid-column:1/-1;text-align:center;padding:2rem;opacity:0.5">
          <p style="margin:0;font-size:0.875rem">Unable to load market data. Check your connection.</p>
        </div>`;
      }
    }
  }

  /* ================================================================
     CHART BUTTON SETUP
     ================================================================ */
  function setupChartButtons() {
    qsa('.asset-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.dataset.symbol === currentChart) return;
        updateChart(btn.dataset.symbol, currentTimeframe);
      });
    });
    qsa('.tf-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.dataset.tf === currentTimeframe) return;
        updateChart(currentChart, btn.dataset.tf);
      });
    });
  }

  /* ================================================================
     LAUNCHER
     ================================================================ */
  function openLauncher(e) {
    if (e) e.preventDefault();
    const $ov = el('launcher-overlay');
    if ($ov) $ov.classList.add('active');
  }
  function closeLauncher() {
    const $ov = el('launcher-overlay');
    if ($ov) $ov.classList.remove('active');
  }
  function setupLauncher() {
    // Intercept any download / .exe / .zip anchor (except those inside launcher itself)
    qsa('a[href*="#download"], a[href*=".exe"], a[href*=".zip"]').forEach(a => {
      if (!a.closest('.launcher-window')) {
        a.addEventListener('click', openLauncher);
      }
    });
    const $close = el('launcher-close-btn');
    if ($close) $close.addEventListener('click', closeLauncher);
    const $ov = el('launcher-overlay');
    if ($ov) $ov.addEventListener('click', e => { if (e.target === $ov) closeLauncher(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLauncher(); });
  }

  /* ================================================================
     CINEMATIC LOADER
     ================================================================ */
  function hideLoader() {
    const $loader = el('cinematic-loader');
    if (!$loader) return;
    $loader.classList.add('fade-out');
    setTimeout(() => { if ($loader.parentNode) $loader.parentNode.removeChild($loader); }, 1200);
  }

  /* ================================================================
     MOBILE NAV
     ================================================================ */
  function setupMobileNav() {
    const toggle = el('nav-toggle'), navLinks = el('nav-links');
    if (!toggle || !navLinks) return;
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      navLinks.classList.toggle('open', !open);
    });
    qsa('a', navLinks).forEach(a => a.addEventListener('click', () => {
      toggle.setAttribute('aria-expanded', 'false');
      navLinks.classList.remove('open');
    }));
    document.addEventListener('click', e => {
      if (!toggle.contains(e.target) && !navLinks.contains(e.target)) {
        toggle.setAttribute('aria-expanded', 'false');
        navLinks.classList.remove('open');
      }
    });
  }

  /* ================================================================
     STICKY NAV SCROLL
     ================================================================ */
  function setupStickyNav() {
    const nav = qs('.top-nav');
    if (!nav) return;
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 60);
    });
  }

  /* ================================================================
     MISC SETUP
     ================================================================ */
  function setFooterYear() {
    const yr = el('footer-year');
    if (yr) yr.textContent = new Date().getFullYear();
  }
  function setHeroDate() {
    const d = el('hero-updated-date');
    if (d) d.textContent = `Updated: ${new Date().toLocaleDateString('en-CA')}`;
  }

  /* ================================================================
     ONLINE / OFFLINE HANDLING
     ================================================================ */
  window.addEventListener('online',  () => { isOnline = true;  connectWebSocket(); refreshMarketData(); });
  window.addEventListener('offline', () => { isOnline = false; setLiveStatus('error', 'Offline'); });

  /* ================================================================
     RESIZE HANDLER
     ================================================================ */
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      const prices = chartData[currentChart];
      if (prices && $canvas) {
        const first = prices[0]?.[1] || 0, last = prices[prices.length - 1]?.[1] || 0;
        drawChart($canvas, prices, last >= first ? 'up' : 'down');
      }
    }, 120);
  });

  /* ================================================================
     INIT
     ================================================================ */
  function init() {
    $marketCards  = el('market-cards');
    $tickerInner  = el('ticker-inner');
    $liveBadge    = el('live-status-badge');
    $liveText     = el('live-status-text');
    $canvas       = el('priceChart');
    $chartPrice   = el('chart-price');
    $chartChange  = el('chart-change');
    $chartUpdated = el('chart-last-updated');
    $chartLabel   = el('chart-symbol-label');

    setFooterYear();
    setHeroDate();
    setupChartButtons();
    setupMobileNav();
    setupStickyNav();
    setupLauncher();
    setupChartCrosshair();

    // Cinematic loader — hide after data is ready (max 2.5s)
    const loaderTimeout = setTimeout(hideLoader, 2500);

    // Boot: connect WS + fetch REST in parallel
    connectWebSocket();
    refreshMarketData().then(() => {
      clearTimeout(loaderTimeout);
      hideLoader();
      updateChart('BTC');
    }).catch(() => {
      clearTimeout(loaderTimeout);
      hideLoader();
    });

    // REST polling interval (maintains 24h stats + volume)
    setInterval(() => {
      refreshMarketData();
      // Expire cached REST data to get fresh on next fetch
      if (chartData[currentChart]) chartData[currentChart][currentTimeframe] = null;
      updateChart(currentChart, currentTimeframe);
    }, COINGECKO_REFRESH_MS);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
